// Information Expert: catálogo conhece e gerencia consultas
// Singleton Pattern

import type { Consulta } from "@/lib/types"

export class CatalogoConsulta {
  private static instance: CatalogoConsulta
  private consultas: Map<string, Consulta> = new Map()

  private constructor() {
    // Dados de exemplo
    this.consultas.set("CONS001", {
      CodConsulta: "CONS001",
      Status: "concluida",
      CodPaciente: "PAC001",
      CodMedico: "MED001",
      CodDisp: "DISP001",
    }
    "CONS002", {
      CodConsulta: "CONS002",
      Status: "concluida",
      CodPaciente: "PAC001",
      CodMedico: "MED002",
      CodDisp: "DISP002",
    }
    )
  }



  public static getInstance(): CatalogoConsulta {
    if (!CatalogoConsulta.instance) {
      CatalogoConsulta.instance = new CatalogoConsulta()
    }
    return CatalogoConsulta.instance
  }

  public adicionar(consulta: Consulta): void {
    this.consultas.set(consulta.CodConsulta, consulta)
  }

  public buscarPorCodigo(codConsulta: string): Consulta | null {
    return this.consultas.get(codConsulta) || null
  }

  public buscarPorPaciente(codPaciente: string): Consulta[] {
    return Array.from(this.consultas.values()).filter((c) => c.CodPaciente === codPaciente)
  }

  public buscarConsultasConcluidas(codPaciente: string): Consulta[] {
    return this.buscarPorPaciente(codPaciente).filter((c) => c.Status === "concluida")
  }

  public atualizarStatus(codConsulta: string, status: Consulta["Status"]): boolean {
    const consulta = this.consultas.get(codConsulta)
    if (consulta) {
      consulta.Status = status
      return true
    }
    return false
  }
}

export const catalogoConsulta = CatalogoConsulta.getInstance()
