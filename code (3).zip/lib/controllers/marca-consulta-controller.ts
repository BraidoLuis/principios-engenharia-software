// Controller: coordena o caso de uso "Marcar Consulta"
// Low Coupling: não conhece detalhes internos das entidades
// Segue exatamente o diagrama de comunicação fornecido

import { catalogoPaciente } from "@/lib/catalogues/catalogo-paciente"
import { catalogoDisponibilidade } from "@/lib/catalogues/catalogo-disponibilidade"
import type { Consulta, Pagamento } from "@/lib/types"

export class MarcaConsultaController {
  private static instance: MarcaConsultaController
  private consultas: Map<string, Consulta> = new Map()
  private pagamentos: Map<string, Pagamento> = new Map()

  private constructor() {}

  public static getInstance(): MarcaConsultaController {
    if (!MarcaConsultaController.instance) {
      MarcaConsultaController.instance = new MarcaConsultaController()
    }
    return MarcaConsultaController.instance
  }

  // Método principal do caso de uso conforme diagrama de comunicação
  public criarConsulta(
    codPaciente: string,
    codDisp: string,
    valor: number,
    dataPagam: string,
    horaPagam: string,
    tipoPagam: "credito" | "debito" | "pix" | "dinheiro",
  ): { sucesso: boolean; consulta?: Consulta; mensagem: string } {
    // 1.1. Encontrar paciente no catálogo
    const paciente = catalogoPaciente.encontraPaciente(codPaciente)
    if (!paciente) {
      return { sucesso: false, mensagem: "Paciente não encontrado" }
    }

    // 1.2. Encontrar disponibilidade no catálogo
    const disponibilidade = catalogoDisponibilidade.encontraDisponibilidade(codDisp)
    if (!disponibilidade) {
      return { sucesso: false, mensagem: "Disponibilidade não encontrada" }
    }

    if (disponibilidade.Reservado) {
      return { sucesso: false, mensagem: "Horário já reservado" }
    }

    // 1.3. Delega ao paciente a criação da consulta
    // (Na prática, o controller coordena mas a lógica fica encapsulada)
    const resultado = this.criaConsultaParaPaciente(
      paciente.CodPaciente,
      disponibilidade.CodDisp,
      valor,
      dataPagam,
      horaPagam,
      tipoPagam,
    )

    if (resultado.sucesso) {
      // 1.3.2. Reservar disponibilidade
      catalogoDisponibilidade.reservaDisponibilidade(codDisp)
    }

    return resultado
  }

  // Creator: cria consulta e pagamento (encapsula a lógica do diagrama 1.3.1)
  private criaConsultaParaPaciente(
    codPaciente: string,
    codDisp: string,
    valor: number,
    dataPagam: string,
    horaPagam: string,
    tipoPagam: "credito" | "debito" | "pix" | "dinheiro",
  ): { sucesso: boolean; consulta?: Consulta; mensagem: string } {
    try {
      // 1.3.1.1. Criar Pagamento
      const codPagamento = `PAG${Date.now()}`
      const pagamento: Pagamento = {
        CodPagamento: codPagamento,
        Valor: valor,
        DataPagam: dataPagam,
        HoraPagam: horaPagam,
        TipoPagam: tipoPagam,
      }

      // 1.3.1. Criar Consulta
      const codConsulta = `CON${Date.now()}`
      const consulta: Consulta = {
        CodConsulta: codConsulta,
        Status: "agendada",
        CodPaciente: codPaciente,
        CodDisp: codDisp,
      }

      // Vincular pagamento à consulta
      pagamento.CodConsulta = codConsulta

      // Armazenar no repositório
      this.consultas.set(codConsulta, consulta)
      this.pagamentos.set(codPagamento, pagamento)

      return {
        sucesso: true,
        consulta,
        mensagem: "Consulta marcada com sucesso",
      }
    } catch (error) {
      return {
        sucesso: false,
        mensagem: "Erro ao criar consulta: " + (error as Error).message,
      }
    }
  }

  public getConsulta(codConsulta: string): Consulta | null {
    return this.consultas.get(codConsulta) || null
  }

  public getConsultasPorPaciente(codPaciente: string): Consulta[] {
    return Array.from(this.consultas.values()).filter((c) => c.CodPaciente === codPaciente)
  }

  public getPagamento(codPagamento: string): Pagamento | null {
    return this.pagamentos.get(codPagamento) || null
  }
}

export const marcaConsultaController = MarcaConsultaController.getInstance()
